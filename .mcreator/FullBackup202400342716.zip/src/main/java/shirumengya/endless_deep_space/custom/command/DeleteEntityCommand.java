package shirumengya.endless_deep_space.custom.command;

import com.google.common.collect.ImmutableList;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.entity.EntityInLevelCallback;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import shirumengya.endless_deep_space.custom.networking.ModMessages;
import shirumengya.endless_deep_space.custom.networking.packet.DeleteEntityS2CPacket;
import shirumengya.endless_deep_space.mixins.EntityAccessor;

import java.util.Collection;

@Mod.EventBusSubscriber
public class DeleteEntityCommand {

   @SubscribeEvent
   public static void register(RegisterCommandsEvent event) {
      event.getDispatcher().register(Commands.literal("delete").requires((p_137812_) -> {
         return p_137812_.hasPermission(2);
      }).executes((p_137817_) -> {
         return delete(p_137817_.getSource(), ImmutableList.of(p_137817_.getSource().getEntityOrException()));
      }).then(Commands.argument("targets", EntityArgument.entities()).executes((p_137810_) -> {
         return delete(p_137810_.getSource(), EntityArgument.getEntities(p_137810_, "targets"));
      })));
   }

   private static int delete(CommandSourceStack p_137814_, Collection<? extends Entity> p_137815_) {
      for(Entity entity : p_137815_) {
         if (entity instanceof ServerPlayer player) {
            player.connection.disconnect(Component.translatable("commands.endless_deep_space.delete.success.single", player.getDisplayName()));
         } else {
            ModMessages.sendToAllPlayers(new DeleteEntityS2CPacket(entity.getId()));
            entity.setRemoved(Entity.RemovalReason.DISCARDED);
            entity.canUpdate(false);
            entity.gameEvent(GameEvent.ENTITY_DIE);
            //entity.setPos(new Vec3(Double.NaN, Double.NaN, Double.NEGATIVE_INFINITY));
            entity.setRemoved(Entity.RemovalReason.UNLOADED_TO_CHUNK);
            entity.setLevelCallback(EntityInLevelCallback.NULL);
            entity.tickCount = Integer.MIN_VALUE;
            entity.setDeltaMovement(new Vec3(Double.NaN, Double.NaN, Double.NEGATIVE_INFINITY));
            entity.setBoundingBox(new AABB(Vec3.ZERO, Vec3.ZERO));
            ((EntityAccessor) entity).setBlockPosition(new BlockPos(Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE));
            ((EntityAccessor) entity).setChunkPosition(new ChunkPos(Integer.MAX_VALUE, Integer.MIN_VALUE));
            ((EntityAccessor) entity).setDeltaMovement(new Vec3(Double.NaN, Double.NaN, Double.NEGATIVE_INFINITY));
            ((EntityAccessor) entity).setPosition(new Vec3(Double.NaN, Double.NaN, Double.NEGATIVE_INFINITY));
            ((EntityAccessor) entity).setRemovalReason(Entity.RemovalReason.UNLOADED_TO_CHUNK);
            entity.invalidateCaps();
         }
      }

      if (p_137815_.size() == 1) {
         p_137814_.sendSuccess(() -> {
            return Component.translatable("commands.endless_deep_space.delete.success.single", p_137815_.iterator().next().getDisplayName());
         }, true);
      } else {
         p_137814_.sendSuccess(() -> {
            return Component.translatable("commands.endless_deep_space.delete.success.multiple", p_137815_.size());
         }, true);
      }

      return p_137815_.size();
   }
}