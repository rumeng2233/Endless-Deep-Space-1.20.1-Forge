package shirumengya.endless_deep_space.custom.entity.boss;

import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;

public abstract class PartBoss extends Monster {
   public PartBoss(EntityType<? extends PartBoss> p_33002_, Level p_33003_) {
       super(p_33002_, p_33003_);
   }

   public abstract ColoredEntityPart[] getSubEntities();

    @Override
    public final boolean isMultipartEntity() {
        return true;
    }

    public void recreateFromPacket(ClientboundAddEntityPacket p_218825_) {
        super.recreateFromPacket(p_218825_);
        if (true) return; // Forge: Fix MC-158205: Moved into setId()
        ColoredEntityPart[] aEnderLordPart = this.getSubEntities();

        for(int i = 0; i < aEnderLordPart.length; ++i) {
            aEnderLordPart[i].setId(i + p_218825_.getId());
        }

    }

    @Override
    public final net.minecraftforge.entity.PartEntity<?>[] getParts() {
        return this.getSubEntities();
    }
}