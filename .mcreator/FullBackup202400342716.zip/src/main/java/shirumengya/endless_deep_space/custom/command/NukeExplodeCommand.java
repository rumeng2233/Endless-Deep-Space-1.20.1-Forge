package shirumengya.endless_deep_space.custom.command;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import shirumengya.endless_deep_space.custom.entity.ScreenShakeEntity;
import shirumengya.endless_deep_space.custom.world.explosion.CustomExplosion;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class NukeExplodeCommand {

   @SubscribeEvent
   public static void registerCommand(RegisterCommandsEvent event) {
      event.getDispatcher().register(Commands.literal("nuke").requires(s -> s.hasPermission(2))
                      .then(Commands.argument("Blockpos", BlockPosArgument.blockPos())
                              .then(Commands.argument("SourceEntity", EntityArgument.entity())
                                      .then(Commands.argument("Radius", FloatArgumentType.floatArg(0))
                                              .then(Commands.argument("Fire", BoolArgumentType.bool())
                                                      .then(Commands.argument("MaxBlastPower", DoubleArgumentType.doubleArg(0))
                                                              .then(Commands.argument("yShorten", FloatArgumentType.floatArg(0))
                                                                      .then(Commands.argument("ScreenShake", BoolArgumentType.bool())
                                                                          .then(Commands.literal("KEEP").executes((p_137810_) -> {
                                                                             return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), EntityArgument.getEntity(p_137810_, "SourceEntity"), FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.KEEP);
                                                                          }))
                                                                          .then(Commands.literal("DESTROY").executes((p_137810_) -> {
                                                                             return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), EntityArgument.getEntity(p_137810_, "SourceEntity"), FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.DESTROY);
                                                                          }))
                                                                          .then(Commands.literal("DESTROY_WITH_DECAY").executes((p_137810_) -> {
                                                                             return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), EntityArgument.getEntity(p_137810_, "SourceEntity"), FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.DESTROY_WITH_DECAY);
                                                                          }))
                                                                          .then(Commands.literal("DESTROY_NO_LOOT").executes((p_137810_) -> {
                                                                              return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), EntityArgument.getEntity(p_137810_, "SourceEntity"), FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.DESTROY_NO_LOOT);
                                                                          }))
                                                              ))))))
                              .then(Commands.literal("null")
                                      .then(Commands.argument("Radius", FloatArgumentType.floatArg(0))
                                              .then(Commands.argument("Fire", BoolArgumentType.bool())
                                                      .then(Commands.argument("MaxBlastPower", DoubleArgumentType.doubleArg(0))
                                                              .then(Commands.argument("yShorten", FloatArgumentType.floatArg(0))
                                                                      .then(Commands.argument("ScreenShake", BoolArgumentType.bool())
                                                                          .then(Commands.literal("KEEP").executes((p_137810_) -> {
                                                                             return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), null, FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.KEEP);
                                                                          }))
                                                                          .then(Commands.literal("DESTROY").executes((p_137810_) -> {
                                                                             return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), null, FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.DESTROY);
                                                                          }))
                                                                          .then(Commands.literal("DESTROY_WITH_DECAY").executes((p_137810_) -> {
                                                                             return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), null, FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.DESTROY_WITH_DECAY);
                                                                          }))
                                                                          .then(Commands.literal("DESTROY_NO_LOOT").executes((p_137810_) -> {
                                                                              return nukeExplode(p_137810_.getSource(), BlockPosArgument.getBlockPos(p_137810_, "Blockpos"), null, FloatArgumentType.getFloat(p_137810_, "Radius"), BoolArgumentType.getBool(p_137810_, "Fire"), DoubleArgumentType.getDouble(p_137810_, "MaxBlastPower"), FloatArgumentType.getFloat(p_137810_, "yShorten"), BoolArgumentType.getBool(p_137810_, "ScreenShake"), CustomExplosion.BlockInteraction.DESTROY_NO_LOOT);
                                                                          }))
                                                                      ))))))));
   }

   private static int nukeExplode(CommandSourceStack p_137814_, BlockPos blockPos, @Nullable Entity entity, float radius, boolean fire, double maxBlastPower, float yShorten, boolean screenShake, CustomExplosion.BlockInteraction blockInteraction) {
      ServerLevel level = p_137814_.getLevel();
      CustomExplosion.nukeExplode(level, entity, blockPos.getX(), blockPos.getY(), blockPos.getZ(), radius, fire, blockInteraction, maxBlastPower, yShorten);
      if (screenShake) {
          ScreenShakeEntity.ScreenShake(level, new Vec3(blockPos.getX(), blockPos.getY(), blockPos.getZ()), radius, radius / 100.0F, 140, 40);
      }
      p_137814_.sendSuccess(() -> {
         return Component.translatable("commands.endless_deep_space.nuke.success", blockPos.toString(), entity == null ? Component.translatable("commands.endless_deep_space.nuke.success.nullentity") : entity.getDisplayName(), radius, fire, maxBlastPower, yShorten, screenShake, blockInteraction);
      }, true);
      return 1;
   }
}