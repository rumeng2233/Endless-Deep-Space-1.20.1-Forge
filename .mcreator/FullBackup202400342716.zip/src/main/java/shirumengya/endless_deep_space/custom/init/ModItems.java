package shirumengya.endless_deep_space.custom.init;

import net.minecraft.world.item.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import shirumengya.endless_deep_space.EndlessDeepSpaceMod;
import shirumengya.endless_deep_space.custom.item.PocketKnifeItem;

import static net.minecraft.world.item.Items.registerBlock;

public class ModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EndlessDeepSpaceMod.MODID);

	public static final RegistryObject<Item> ENDER_LORD_SPAWN_EGG = REGISTRY.register("ender_lord_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.ENDER_LORD, -15517642, -11141121, new Item.Properties()));
	public static final RegistryObject<Item> WOODEN_POCKET_KNIFE = REGISTRY.register("wooden_pocket_knife", () -> new PocketKnifeItem(Tiers.WOOD, 3, -2.4F, new Item.Properties()));
	public static final RegistryObject<Item> STONE_POCKET_KNIFE = REGISTRY.register("stone_pocket_knife", () -> new PocketKnifeItem(Tiers.STONE, 3, -2.4F, new Item.Properties()));
	public static final RegistryObject<Item> IRON_POCKET_KNIFE = REGISTRY.register("iron_pocket_knife", () -> new PocketKnifeItem(Tiers.IRON, 3, -2.4F, new Item.Properties()));
	public static final RegistryObject<Item> GOLDEN_POCKET_KNIFE = REGISTRY.register("golden_pocket_knife", () -> new PocketKnifeItem(Tiers.GOLD, 3, -2.4F, new Item.Properties()));
	public static final RegistryObject<Item> DIAMOND_POCKET_KNIFE = REGISTRY.register("diamond_pocket_knife", () -> new PocketKnifeItem(Tiers.DIAMOND, 3, -2.4F, new Item.Properties()));
	public static final RegistryObject<Item> NETHERITE_POCKET_KNIFE = REGISTRY.register("netherite_pocket_knife", () -> new PocketKnifeItem(Tiers.NETHERITE, 3, -2.4F, new Item.Properties()));
	public static final RegistryObject<Item> MUTATION_RAVAGER_SPAWN_EGG = REGISTRY.register("mutation_ravager_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.MUTATION_RAVAGER, -6710887, -10066330, new Item.Properties()));
	public static final RegistryObject<Item> TRANSFORM_STATION = block(ModBlocks.TRANSFORM_STATION);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
