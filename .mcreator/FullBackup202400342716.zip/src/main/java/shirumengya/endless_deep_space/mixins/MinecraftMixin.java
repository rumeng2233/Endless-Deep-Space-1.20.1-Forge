package shirumengya.endless_deep_space.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import shirumengya.endless_deep_space.custom.client.sounds.ModMusicManager;

import javax.annotation.Nullable;

@Mixin({Minecraft.class})
public abstract class MinecraftMixin {
	private static final Logger LOGGER = LogManager.getLogger(Minecraft.class);

	public MinecraftMixin() {

	}

	@Inject(method = {"pauseGame"}, at = {@At("HEAD")}, cancellable = true)
	public void pauseGame(boolean p_91359_, CallbackInfo ci) {
		if (Minecraft.getInstance().screen == null) {
         	boolean flag = Minecraft.getInstance().hasSingleplayerServer() && !Minecraft.getInstance().getSingleplayerServer().isPublished();
         	if (flag) {
            	Minecraft.getInstance().setScreen(new PauseScreen(!p_91359_));
         	} else {
            	Minecraft.getInstance().setScreen(new PauseScreen(true));
         	}

      	}
		ci.cancel();
	}

	@Inject(method = {"runTick"}, at = {@At("HEAD")}, cancellable = true)
	public void tick(boolean p_91384_, CallbackInfo ci) {
		Minecraft.getInstance().getProfiler().push("EndlessDeepSpaceModClientSideTick");
		ModMusicManager.EndlessDeepSpaceModClientSideTick();
		Minecraft.getInstance().getProfiler().pop();
	}

	@Inject(method = {"setScreen"}, at = {@At("TAIL")}, cancellable = true)
	public void setScreen(@Nullable Screen p_91153_, CallbackInfo info) {
		if (Minecraft.getInstance().screen != null) {
			LOGGER.info("Opening Screen:[" + Minecraft.getInstance().screen.getClass().getCanonicalName() + "]");
		} else {
			LOGGER.info("Opening Screen:[null]");
		}
	}
}
