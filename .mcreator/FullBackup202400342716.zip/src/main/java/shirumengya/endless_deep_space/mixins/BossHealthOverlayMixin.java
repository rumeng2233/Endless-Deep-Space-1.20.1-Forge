package shirumengya.endless_deep_space.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.BossHealthOverlay;
import net.minecraft.client.gui.components.LerpingBossEvent;
import net.minecraft.client.sounds.MusicManager;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import shirumengya.endless_deep_space.custom.client.gui.CustomBossBar;
import shirumengya.endless_deep_space.custom.config.ModClientConfig;

import java.util.Map;
import java.util.UUID;

@Mixin({BossHealthOverlay.class})
public abstract class BossHealthOverlayMixin {
	@Shadow @Final private Map<UUID, LerpingBossEvent> events;

	@Shadow @Final private Minecraft minecraft;

	public BossHealthOverlayMixin() {
		
	}

	@Inject(method = {"render"}, at = {@At("HEAD")}, cancellable = true)
	public void render(GuiGraphics p_283175_, CallbackInfo ci) {
		if (ModClientConfig.CUSTOM_BOSSBAR.get()) {
			if (!this.events.isEmpty()) {
				int i = p_283175_.guiWidth();
				int j = 12;

				for(LerpingBossEvent lerpingbossevent : this.events.values()) {
					int k = i / 2 - 91;
					var event = net.minecraftforge.client.ForgeHooksClient.onCustomizeBossEventProgress(p_283175_, this.minecraft.getWindow(), lerpingbossevent, k, j, 10 + this.minecraft.font.lineHeight);
					if (!event.isCanceled()) {
						CustomBossBar customBossBar = CustomBossBar.customBossBars.get(-2);
						customBossBar.renderBossBar(event, Component.empty(), -2);
					}
					j += event.getIncrement();
					if (j >= p_283175_.guiHeight() / 3) {
						break;
					}
				}
			}
			ci.cancel();
		}
	}
}
