package shirumengya.endless_deep_space.mixins;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.stats.Stats;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.HoneyBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import shirumengya.endless_deep_space.custom.config.ModCommonConfig;
import shirumengya.endless_deep_space.custom.entity.boss.enderlord.EnderLord;
import shirumengya.endless_deep_space.custom.init.ModMobEffects;
import shirumengya.endless_deep_space.init.EndlessDeepSpaceModMobEffects;
import shirumengya.endless_deep_space.init.EndlessDeepSpaceModSounds;

import javax.annotation.Nullable;
import java.util.Objects;

@Mixin({LivingEntity.class})
public abstract class LivingEntityMixin extends Entity {
	@Unique
	private static final EntityDataAccessor<Integer> DATA_VERTIGO_TIME = SynchedEntityData.defineId(LivingEntityMixin.class, EntityDataSerializers.INT);
	@Shadow
	private float speed;

	@Shadow @Nullable protected abstract SoundEvent getDeathSound();

	@Shadow protected abstract float getSoundVolume();

	@Shadow protected abstract void breakItem(ItemStack p_21279_);

	@Shadow protected abstract void swapHandItems();

	@Shadow protected abstract void makePoofParticles();

	public LivingEntityMixin(EntityType<? extends LivingEntity> p_20966_, Level p_20967_) {
		super(p_20966_, p_20967_);
	}

	@Unique
	public void setDataVertigoTime(LivingEntity entity, int value) {
		entity.getEntityData().set(DATA_VERTIGO_TIME, Math.max(0, value));
	}

	@Unique
	public int getDataVertigoTime(LivingEntity entity) {
		return entity.getEntityData().get(DATA_VERTIGO_TIME);
	}

	@Inject(method = {"defineSynchedData"}, at = {@At("HEAD")})
	public void defineSynchedData(CallbackInfo ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		entity.getEntityData().define(DATA_VERTIGO_TIME, 0);
	}

	@Inject(method = {"addAdditionalSaveData"}, at = {@At("HEAD")})
	public void addAdditionalSaveData(CompoundTag p_21145_, CallbackInfo ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		p_21145_.putInt("VertigoTime", this.getDataVertigoTime(entity));
	}

	@Inject(method = {"readAdditionalSaveData"}, at = {@At("HEAD")})
	public void readAdditionalSaveData(CompoundTag p_21145_, CallbackInfo ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		this.setDataVertigoTime(entity, p_21145_.getInt("VertigoTime"));
	}

	@Inject(method = {"tick"}, at = {@At("HEAD")})
	public void tick(CallbackInfo ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		if (this.getDataVertigoTime(entity) > 0) {
			if (entity.tickCount % 20 == 0) {
				for (int i = 0; i < 10; i++) {
					float f = (entity.getRandom().nextFloat() - 0.5F) * entity.getBbWidth();
					float f1 = (entity.getRandom().nextFloat() - 0.5F) * entity.getBbHeight();
					float f2 = (entity.getRandom().nextFloat() - 0.5F) * entity.getBbWidth();
					entity.level().addAlwaysVisibleParticle(ParticleTypes.ANGRY_VILLAGER, entity.getX() + (double)f, entity.getY() + 2.0D + (double)f1, entity.getZ() + (double)f2, 0.0D, 0.0D, 0.0D);
				}
			}
			this.setDataVertigoTime(entity, this.getDataVertigoTime(entity) - 1);
		}
	}

	@Inject(method = {"canAttack(Lnet/minecraft/world/entity/LivingEntity;)Z"}, at = {@At("HEAD")}, cancellable = true)
	public void canAttack(CallbackInfoReturnable<Boolean> ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		if (this.getDataVertigoTime(entity) > 0) {
			ci.setReturnValue(false);
		}
	}

	@Inject(method = {"getMaxHealth"}, at = {@At("HEAD")}, cancellable = true)
	public void getDragonMaxHealth(CallbackInfoReturnable<Float> ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		if (entity instanceof EnderLord) {
			ci.setReturnValue((float)ModCommonConfig.ENDER_LORD_MAX_HEALTH.get());
		}
	}

	@Inject(method = {"getSpeed"}, at = {@At("HEAD")}, cancellable = true)
	public void getSpeed(CallbackInfoReturnable<Float> ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		if (this.getDataVertigoTime(entity) > 0) {
			ci.setReturnValue(0.0F);
		}
	}

	@Inject(method = {"setSpeed"}, at = {@At("HEAD")}, cancellable = true)
	public void setSpeed(float p_21320_, CallbackInfo ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		if (this.getDataVertigoTime(entity) > 0) {
			this.speed = 0.0F;
			ci.cancel();
		}
	}

	@Inject(method = {"handleEntityEvent"}, at = {@At("HEAD")}, cancellable = true)
	public void handleEntityEvent(byte p_20975_, CallbackInfo ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);
		switch (p_20975_) {
			case -1:
				entity.playSound(EndlessDeepSpaceModSounds.ITEM_SWORD_BLOCK.get(), 1.0F, 0.8F + entity.level().random.nextFloat() * 0.4F);
				break;
			case 3:
				SoundEvent soundevent = this.getDeathSound();
				if (soundevent != null) {
					entity.playSound(soundevent, this.getSoundVolume(), (entity.getRandom().nextFloat() - entity.getRandom().nextFloat()) * 0.2F + 1.0F);
				}

				if (!(entity instanceof Player)) {
					entity.setHealth(0.0F);
					entity.die(this.damageSources().generic());
				}
				break;
			case 29:
				entity.playSound(SoundEvents.SHIELD_BLOCK, 1.0F, 0.8F + entity.level().random.nextFloat() * 0.4F);
				break;
			case 30:
				entity.playSound(SoundEvents.SHIELD_BREAK, 0.8F, 0.8F + entity.level().random.nextFloat() * 0.4F);
				break;
			case 46:
				int i = 128;

				for(int j = 0; j < 128; ++j) {
					double d0 = (double)j / 127.0D;
					float f = (entity.getRandom().nextFloat() - 0.5F) * 0.2F;
					float f1 = (entity.getRandom().nextFloat() - 0.5F) * 0.2F;
					float f2 = (entity.getRandom().nextFloat() - 0.5F) * 0.2F;
					double d1 = Mth.lerp(d0, entity.xo, entity.getX()) + (entity.getRandom().nextDouble() - 0.5D) * (double)entity.getBbWidth() * 2.0D;
					double d2 = Mth.lerp(d0, entity.yo, entity.getY()) + entity.getRandom().nextDouble() * (double)entity.getBbHeight();
					double d3 = Mth.lerp(d0, entity.zo, entity.getZ()) + (entity.getRandom().nextDouble() - 0.5D) * (double)entity.getBbWidth() * 2.0D;
					entity.level().addParticle(ParticleTypes.PORTAL, d1, d2, d3, (double)f, (double)f1, (double)f2);
				}
				break;
			case 47:
				this.breakItem(entity.getItemBySlot(EquipmentSlot.MAINHAND));
				break;
			case 48:
				this.breakItem(entity.getItemBySlot(EquipmentSlot.OFFHAND));
				break;
			case 49:
				this.breakItem(entity.getItemBySlot(EquipmentSlot.HEAD));
				break;
			case 50:
				this.breakItem(entity.getItemBySlot(EquipmentSlot.CHEST));
				break;
			case 51:
				this.breakItem(entity.getItemBySlot(EquipmentSlot.LEGS));
				break;
			case 52:
				this.breakItem(entity.getItemBySlot(EquipmentSlot.FEET));
				break;
			case 54:
				HoneyBlock.showJumpParticles(entity);
				break;
			case 55:
				this.swapHandItems();
				break;
			case 60:
				this.makePoofParticles();
				break;
			default:
				super.handleEntityEvent(p_20975_);
		}

		ci.cancel();
	}

	@Inject(method = {"checkTotemDeathProtection"}, at = {@At("HEAD")}, cancellable = true)
	private void checkTotemDeathProtection(DamageSource p_21263_, CallbackInfoReturnable<Boolean> ci) {
		LivingEntity entity = ((LivingEntity)(Object)this);

		if (entity.hasEffect(EndlessDeepSpaceModMobEffects.TOTEM_OF_UNDYING.get())) {
			int amplifier = Objects.requireNonNull(entity.getEffect(EndlessDeepSpaceModMobEffects.TOTEM_OF_UNDYING.get())).getAmplifier();
			int duration = Objects.requireNonNull(entity.getEffect(EndlessDeepSpaceModMobEffects.TOTEM_OF_UNDYING.get())).getDuration();
			if (entity instanceof ServerPlayer serverplayer) {
				CriteriaTriggers.USED_TOTEM.trigger(serverplayer, new ItemStack(Items.TOTEM_OF_UNDYING));
			}
			entity.setHealth(amplifier + 1);
			entity.removeAllEffects();
			if (amplifier - 1 >= 0) {
				entity.addEffect(new MobEffectInstance(EndlessDeepSpaceModMobEffects.TOTEM_OF_UNDYING.get(), duration, amplifier - 1));
			}
			entity.addEffect(new MobEffectInstance(ModMobEffects.DAMAGE_REDUCTION.get(), 200, Math.max(0, amplifier - 1)));
			entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
			entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 100, 1));
			entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 800, 0));
			entity.level().broadcastEntityEvent(entity, (byte) -2);

			ci.setReturnValue(true);
		} else {
			if (p_21263_.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
				ci.setReturnValue(false);
			} else {
				ItemStack itemstack = null;

				for (InteractionHand interactionhand : InteractionHand.values()) {
					ItemStack itemstack1 = entity.getItemInHand(interactionhand);
					if (itemstack1.is(Items.TOTEM_OF_UNDYING) && net.minecraftforge.common.ForgeHooks.onLivingUseTotem(entity, p_21263_, itemstack1, interactionhand)) {
						itemstack = itemstack1.copy();
						itemstack1.shrink(1);
						break;
					}
				}

				if (itemstack != null) {
					if (entity instanceof ServerPlayer) {
						ServerPlayer serverplayer = (ServerPlayer) entity;
						serverplayer.awardStat(Stats.ITEM_USED.get(Items.TOTEM_OF_UNDYING), 1);
						CriteriaTriggers.USED_TOTEM.trigger(serverplayer, itemstack);
					}

					entity.setHealth(1.0F);
					entity.removeAllEffects();
					entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
					entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 100, 1));
					entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 800, 0));
					entity.level().broadcastEntityEvent(entity, (byte) 35);
				}

				ci.setReturnValue(itemstack != null);
			}
		}
	}
}
