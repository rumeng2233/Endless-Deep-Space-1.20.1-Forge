package shirumengya.endless_deep_space.procedures;

public class TotemSwordEWaiDeDiaoLuoTiaoJianProcedure {
	public static boolean execute() {
		return true;
	}
}
