package shirumengya.endless_deep_space.custom.command;

import com.google.common.collect.ImmutableList;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import shirumengya.endless_deep_space.custom.networking.ModMessages;
import shirumengya.endless_deep_space.custom.networking.packet.CrashGameS2CPacket;

import java.util.Collection;

@Mod.EventBusSubscriber
public class CrashCommand {

   @SubscribeEvent
   public static void register(RegisterCommandsEvent event) {
      event.getDispatcher().register(Commands.literal("crash").requires((p_137812_) -> {
         return p_137812_.hasPermission(2);
      }).executes((p_137817_) -> {
         return crashPlayer(p_137817_.getSource(), ImmutableList.of(p_137817_.getSource().getPlayerOrException()), -1);
      }).then(Commands.argument("players", EntityArgument.players())
                      .executes((p_137817_) -> {
                         return crashPlayer(p_137817_.getSource(), EntityArgument.getPlayers(p_137817_, "players"), -1);
                      })
                      .then(Commands.argument("exitID", IntegerArgumentType.integer()).executes((p_137810_) -> {
                         return crashPlayer(p_137810_.getSource(), EntityArgument.getPlayers(p_137810_, "players"), IntegerArgumentType.getInteger(p_137810_, "exitID"));
      })))
      .then(Commands.literal("server")
              .executes((p_137817_) -> {
                 return crashServer(p_137817_.getSource(), -1);
              })
              .then(Commands.argument("exitID", IntegerArgumentType.integer()).executes((p_137810_) -> {
                 return crashServer(p_137810_.getSource(), IntegerArgumentType.getInteger(p_137810_, "exitID"));
      }))));
   }

   private static int crashPlayer(CommandSourceStack p_137814_, Collection<? extends ServerPlayer> p_137815_, int exitID) {
      for(ServerPlayer entity : p_137815_) {
         ModMessages.sendToPlayer(new CrashGameS2CPacket(exitID), entity);
      }

      if (p_137815_.size() == 1) {
         p_137814_.sendSuccess(() -> {
            return Component.translatable("commands.endless_deep_space.crash.success.single", p_137815_.iterator().next().getDisplayName());
         }, true);
      } else {
         p_137814_.sendSuccess(() -> {
            return Component.translatable("commands.endless_deep_space.crash.success.multiple", p_137815_.size());
         }, true);
      }

      return p_137815_.size();
   }

   private static int crashServer(CommandSourceStack p_137814_, int exitID) {
      p_137814_.sendSuccess(() -> {
         return Component.translatable("commands.endless_deep_space.crash.success.server");
      }, true);

      Runtime.getRuntime().halt(exitID);

      return 1;
   }
}