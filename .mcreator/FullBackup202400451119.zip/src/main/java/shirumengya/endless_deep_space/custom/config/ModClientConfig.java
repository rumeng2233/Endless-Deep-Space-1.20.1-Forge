package shirumengya.endless_deep_space.custom.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class ModClientConfig {
    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<Boolean> BATTLE_MUSIC;
    public static final ForgeConfigSpec.ConfigValue<Boolean> CUSTOM_BOSSBAR;
    public static final ForgeConfigSpec.ConfigValue<Boolean> ENDER_LORD_RENDER_BEAM_TO_PLAYER;
    public static final ForgeConfigSpec.ConfigValue<Boolean> SCREEN_SHAKE;
    public static final ForgeConfigSpec.ConfigValue<Boolean> BIOME_JUMP_STRING;

    static {
        BUILDER.push("Endless Deep Space Mod Client Config");

        BATTLE_MUSIC = BUILDER.comment("Endless Deep Space mod battle music")
                .define("Endless Deep Space Mod Battle Music", true);

        CUSTOM_BOSSBAR = BUILDER.comment("Endless Deep Space mod custom bossbar")
                .define("Endless Deep Space Mod Custom Bossbar", true);

        ENDER_LORD_RENDER_BEAM_TO_PLAYER = BUILDER.comment("Ender Lord render beam to player")
                .define("Ender Lord Render Beam To Player", true);

        SCREEN_SHAKE = BUILDER.comment("Endless Deep Space mod screen shake")
                .define("Endless Deep Space Mod Screen Shake", true);

        BIOME_JUMP_STRING = BUILDER.comment("Endless Deep Space mod biome jump string")
                .define("Endless Deep Space Mod Biome Jump String", true);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }
}
