package shirumengya.endless_deep_space.custom.entity.boss.enderlord.phases;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import shirumengya.endless_deep_space.custom.entity.boss.enderlord.EnderLord;

import javax.annotation.Nullable;

public class EnderDragonPhaseManager {
   private static final Logger LOGGER = LogUtils.getLogger();
   private final EnderLord dragon;
   private final DragonPhaseInstance[] phases = new DragonPhaseInstance[EnderDragonPhase.getCount()];
   @Nullable
   private DragonPhaseInstance currentPhase;

   public EnderDragonPhaseManager(EnderLord p_31414_) {
      this.dragon = p_31414_;
      this.setPhase(EnderDragonPhase.HOLDING_PATTERN);
   }

   public void setPhase(EnderDragonPhase<?> p_31417_) {
      if (this.currentPhase == null || p_31417_ != this.currentPhase.getPhase()) {
         if (this.currentPhase != null) {
            this.currentPhase.end();
         }

         this.currentPhase = this.getPhase(p_31417_);
         if (!this.dragon.level().isClientSide) {
            this.dragon.getEntityData().set(EnderLord.DATA_PHASE, p_31417_.getId());
         }

         LOGGER.debug("Dragon is now in phase {} on the {}", p_31417_, this.dragon.level().isClientSide ? "client" : "server");
         this.currentPhase.begin();
      }
   }

   public DragonPhaseInstance getCurrentPhase() {
      return this.currentPhase;
   }

   public <T extends DragonPhaseInstance> T getPhase(EnderDragonPhase<T> p_31419_) {
      int i = p_31419_.getId();
      if (this.phases[i] == null) {
         this.phases[i] = p_31419_.createInstance(this.dragon);
      }

      return (T)this.phases[i];
   }
}