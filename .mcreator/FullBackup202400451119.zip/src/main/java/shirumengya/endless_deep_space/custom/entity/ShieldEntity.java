package shirumengya.endless_deep_space.custom.entity;

public interface ShieldEntity {
   float getShield();

   float getMaxShield();

   boolean hasShield();

   void setShield(float value);
}