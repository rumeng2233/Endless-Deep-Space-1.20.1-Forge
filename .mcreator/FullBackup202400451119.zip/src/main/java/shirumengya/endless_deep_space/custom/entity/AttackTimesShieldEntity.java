package shirumengya.endless_deep_space.custom.entity;

public interface AttackTimesShieldEntity {
    int getShield();

    int getMaxShield();

    boolean hasShield();

    void setShield(int value);
}