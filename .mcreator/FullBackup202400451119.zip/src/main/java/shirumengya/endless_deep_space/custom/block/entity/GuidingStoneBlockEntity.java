package shirumengya.endless_deep_space.custom.block.entity;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BeaconBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import shirumengya.endless_deep_space.custom.block.GuidingStoneBlock;
import shirumengya.endless_deep_space.custom.client.renderer.blockentity.GuidingStoneRenderer;
import shirumengya.endless_deep_space.custom.init.ModBlockEntities;
import shirumengya.endless_deep_space.custom.init.ModBlocks;
import shirumengya.endless_deep_space.custom.world.data.ModWorldData;
import shirumengya.endless_deep_space.init.EndlessDeepSpaceModGameRules;

import java.util.*;

public class GuidingStoneBlockEntity extends BlockEntity {
   public final float[] color;
   public boolean firstPlace;
   public UUID uuid;
   public static final TicketType<BlockPos> GUIDING_STONE = TicketType.create("guiding_stone", Vec3i::compareTo, 40);
   public static final int TICKET_TYPE_MAX_DIFFUSIBLE_VALUE = 33;
   public BeaconBeamSection beamSections;
   public int lastCheckY;
   public int unLastCheckY;
   public boolean lastCheck;
   public boolean unLastCheck;
   
   public GuidingStoneBlockEntity(BlockPos p_155229_, BlockState p_155230_) {
      super(ModBlockEntities.GUIDING_STONE.get(), p_155229_, p_155230_);
      this.color = ((GuidingStoneBlock)p_155230_.getBlock()).color;
      this.uuid = Mth.createInsecureUUID();
      this.beamSections = new BeaconBeamSection(this.color);
   }
   
   @Override
   public AABB getRenderBoundingBox() {
      return BlockEntity.INFINITE_EXTENT_AABB;
   }
   
   public void tick(Level pLevel, BlockPos pPos) {
      int i = pPos.getX();
      int k = pPos.getZ();
      BlockPos blockpos = new BlockPos(i, this.lastCheckY, k);
      BlockState blockstate = pLevel.getBlockState(blockpos);
      this.beamSections.height = GuidingStoneRenderer.MAX_RENDER_Y;
      if (blockstate.is(ModBlocks.PURE_BLACK_GUIDING_STONE.get())) {
         this.beamSections.height = blockpos.getY() - pPos.getY();
         this.lastCheckY = blockpos.getY();
         this.lastCheck = true;
      } else {
         //this.beamSections.minHeight = this.beamSections.minHeight - GuidingStoneRenderer.MAX_RENDER_Y;
         this.lastCheckY++;
         if (this.unLastCheckY > pLevel.getMaxBuildHeight()) {
            this.unLastCheckY = pPos.getY();
         }
         this.lastCheck = false;
      }
   }
   
   public void untick(Level pLevel, BlockPos pPos) {
      int i = pPos.getX();
      int k = pPos.getZ();
      BlockPos blockpos = new BlockPos(i, this.unLastCheckY, k);
      BlockState blockstate = pLevel.getBlockState(blockpos);
      this.beamSections.minHeight = -GuidingStoneRenderer.MAX_RENDER_Y;
      if (blockstate.is(ModBlocks.PURE_BLACK_GUIDING_STONE.get())) {
         this.beamSections.minHeight = -(blockpos.getY() - pPos.getY());
         this.unLastCheckY = blockpos.getY();
         this.unLastCheck = true;
      } else {
         //this.beamSections.height = this.beamSections.height + GuidingStoneRenderer.MAX_RENDER_Y;
         this.unLastCheckY--;
         if (this.unLastCheckY < pLevel.getMinBuildHeight()) {
            this.unLastCheckY = pPos.getY();
         }
         this.unLastCheck = false;
      }
   }
   
   public void tick(Level pLevel, BlockPos pPos, BlockState pState) {
      this.tick(pLevel, pPos);
      this.untick(pLevel, pPos);
      
      /*if (!this.lastCheck && this.unLastCheck) {
         this.beamSections.minHeight = this.beamSections.minHeight - GuidingStoneRenderer.MAX_RENDER_Y;
      } else if (this.lastCheck && !this.unLastCheck) {
         this.beamSections.height = this.beamSections.height + GuidingStoneRenderer.MAX_RENDER_Y;
      }*/
      
      if (pLevel.getGameTime() % 20L == 0L) {
         System.out.println(this.beamSections.minHeight);
         System.out.println(this.beamSections.height);
         
         if (pLevel instanceof ServerLevel serverLevel) {
            ChunkPos chunkPos = serverLevel.getChunkAt(pPos).getPos();
            serverLevel.getChunkSource().addRegionTicket(GUIDING_STONE, chunkPos, TICKET_TYPE_MAX_DIFFUSIBLE_VALUE - serverLevel.getGameRules().getInt(EndlessDeepSpaceModGameRules.GUIDING_STONE_LOAD_TICKET_LEVEL), pPos);
            ModWorldData.WorldVariables worldData = ModWorldData.WorldVariables.get(serverLevel);
            if (worldData.getGuidingStonePos(this.uuid) == null) {
               worldData.addGuidingStonePos(this.uuid, pPos);
               worldData.syncData(serverLevel);
            }
            if (!serverLevel.isLoaded(pPos)) {
               serverLevel.getChunkAt(pPos).setLoaded(true);
            }
         }
      }
      
      if (!this.firstPlace) {
         BeaconBlockEntity.playSound(pLevel, pPos, SoundEvents.BEACON_ACTIVATE);
         this.firstPlace = true;
      }
      
      if (pLevel.getGameTime() % 80L == 0L && !Arrays.equals(this.color, new float[]{0.0F, 0.0F, 0.0F})) {
         BeaconBlockEntity.playSound(pLevel, pPos, SoundEvents.BEACON_AMBIENT);
      }
   }
   
   @Override
   public void setRemoved() {
      BeaconBlockEntity.playSound(this.level, this.worldPosition, SoundEvents.BEACON_DEACTIVATE);
      super.setRemoved();
   }
   
   @Override
   protected void saveAdditional(CompoundTag p_187471_) {
      super.saveAdditional(p_187471_);
      p_187471_.putBoolean("FirstPlace", this.firstPlace);
      p_187471_.putUUID("UUID", this.uuid);
   }
   
   @Override
   public void load(CompoundTag p_155245_) {
      super.load(p_155245_);
      this.firstPlace = p_155245_.getBoolean("FirstPlace");
      this.uuid = p_155245_.getUUID("UUID");
   }
   
   public BeaconBeamSection getBeamSections() {
      return this.beamSections;
   }
   
   public static class BeaconBeamSection {
      public final float[] color;
      public int height;
      public int minHeight;
      
      public BeaconBeamSection(float[] p_58718_) {
         this.color = p_58718_;
         this.height = 1;
         this.minHeight = -1;
      }
      
      public float[] getColor() {
         return this.color;
      }
      
      public int getHeight() {
         return this.height;
      }
      
      public int getMinHeight() {
         return this.minHeight;
      }
   }
}
