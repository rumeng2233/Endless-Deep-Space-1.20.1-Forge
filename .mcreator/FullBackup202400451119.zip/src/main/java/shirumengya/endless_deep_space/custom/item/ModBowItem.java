package shirumengya.endless_deep_space.custom.item;

import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.Vanishable;

public abstract class ModBowItem extends BowItem {
    public ModBowItem(Properties p_40660_) {
        super(p_40660_);
    }
}
